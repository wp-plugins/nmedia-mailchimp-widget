<?php
// Silence is golden. 
?>