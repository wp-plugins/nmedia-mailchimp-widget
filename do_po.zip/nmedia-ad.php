<div class="nm-about-us">

<!-- Get Pro Version -->
<div class="box">
<h2>Pro Version for only $15.00 USD</h2>
<p>
<ul style="list-style:circle">
  <li><strong>Get Premuim Support</strong></li>
  <li><strong>Create List Variables </strong></li>
  <li><strong id="internal-source-marker_0.0015717009082436562">Create List Groups</strong></li>
  <li><strong id="internal-source-marker_0.0015717009082436562">Create List Interest Groups</strong></p>
  </li>
</ul>
<div id="donate">
  <a href='https://www.2checkout.com/checkout/purchase?sid=1686663&quantity=1&product_id=4'>Buy Pro Version</a>
  <p>2CheckOut.com Inc. (Ohio, USA) is an authorized retailer for goods and services provided by N-Media.</p>
</div>

</div>



<!-- Donation -->
<div class="box">
<h2>Make Donation</h2>
<p align="center">
If you think we have developed something useful for you please:
<br />

<a href="http://www.najeebmedia.com/donate">Donate</a>
</p>

<div id="social">
<a href="https://twitter.com/nmedia82" class="twitter-follow-button" data-show-count="true" data-count="horizontal">Follow @nmedia82</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
<br />
</div>

</div>


<div class="box">
<h2>LIKE us, please</h2>
<iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Fpages%2FNmedia%2F191722830857549&amp;width=292&amp;height=258&amp;colorscheme=light&amp;show_faces=true&amp;border_color&amp;stream=false&amp;header=false&amp;appId=262696150470787" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:292px; height:258px;" allowTransparency="true"></iframe>
</div>

<br />



<!-- About us -->
<div class="box">
<a href="http://www.najeebmedia.com/"><img src="http://www.najeebmedia.com/logo.png" alt="Nmedia Logo" border="0" width="175" /></a>
<h2>About Nmedia</h2>
<p>Nmedia has dedicated itself to serve the Wordpress Community  and You. We just Think, Write and Develop in Wordpress and thus loaded ourselves  with all Wordpress features to develop Plugins, Themes. If you site Need:</p>
<ul style="list-style:circle">
  <li><span dir="LTR"> </span>Cosmetic changes</li>
  <li><span dir="LTR"> </span>Theme integration</li>
  <li><span dir="LTR"> </span>Plugin customization</li>
  <li><span dir="LTR"> </span>Plugin development</li>
  <li><span dir="LTR"> </span>Homepage redesign</li>
  <li><span dir="LTR"> </span>Social/viral Plugins</li>
</ul>
<p><br />
  <br />
  Thanks<br />
  Najeeb Ahmad<br />
  <a href="mailto:ceo@najeebmedia.com">ceo@najeebmedia.com</a>
</p>
</div>
</div>