<?php

echo 'passed '.$_POST['email'];
?>